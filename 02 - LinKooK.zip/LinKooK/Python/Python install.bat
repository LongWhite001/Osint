winget install 9PNRBTZXMB4Z
pause