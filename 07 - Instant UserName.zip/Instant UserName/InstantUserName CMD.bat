@echo off
Start chrome.exe https://instantusername.com/